
public interface PriceDecorator
{
    Double getPrice();
}
