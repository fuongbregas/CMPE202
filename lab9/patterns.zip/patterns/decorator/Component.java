package decorator;

public interface Component {

	String operation();

}
