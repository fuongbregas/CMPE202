package factory_method;

public class Electric implements Engine {

}
