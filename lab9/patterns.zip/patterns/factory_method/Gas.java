package factory_method;

public class Gas implements Engine {

}
