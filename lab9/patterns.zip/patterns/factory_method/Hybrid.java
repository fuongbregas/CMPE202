package factory_method;

public class Hybrid implements Engine {

}
