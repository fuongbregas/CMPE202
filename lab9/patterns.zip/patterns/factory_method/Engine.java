package factory_method;

public interface Engine {

}
