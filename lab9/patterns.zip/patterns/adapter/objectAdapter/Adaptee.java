package adapter.objectAdapter;

public interface Adaptee {
 
	public abstract void printMessage(String msg);
}
 
