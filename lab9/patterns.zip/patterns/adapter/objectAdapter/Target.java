package adapter.objectAdapter;

public interface Target {
 
	public abstract void sayHello();
}
 
