package adapter.classAdapter;

public interface Target {
 
	public void sayHello();
}
 
