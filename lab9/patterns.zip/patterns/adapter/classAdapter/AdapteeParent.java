package adapter.classAdapter;

public class AdapteeParent {
 
	public void printMessage(String msg) {
	    System.out.println( msg );
	}
	 
}



