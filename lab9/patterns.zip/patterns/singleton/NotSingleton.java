package singleton;

public class NotSingleton {

}





