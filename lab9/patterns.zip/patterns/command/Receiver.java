package command;

public interface Receiver {
 
	public void doAction() ;
	 
}
 
