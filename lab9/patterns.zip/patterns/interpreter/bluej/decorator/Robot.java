public class Robot implements IRobotCommand
{
         public String getCommand( ) 
         {
             return "Robot: " ;
         }
         
         public void setOption(String o) 
         {
             
         }
}
