
package decorator ;

public interface IRobotCommand
{
     String getCommand( ) ;    
     void setOption(String o) ;
}
