

package interpreter ;

interface Expression {
    public String interpret(String options);
}