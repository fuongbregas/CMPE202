package state;

public enum VmStates {
    ON, OFF, SUSPENDED
}
