package abstract_factory;

public class HybridEngine extends PriusPart {

}
