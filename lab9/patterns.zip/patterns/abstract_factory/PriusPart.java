package abstract_factory;

public abstract class PriusPart extends FactoryPart {

}
