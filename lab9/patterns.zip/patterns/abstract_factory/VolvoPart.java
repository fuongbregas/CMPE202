package abstract_factory;

public abstract class VolvoPart extends FactoryPart {

}
