
public interface QueryResults {
 
	QueryResultsIterator createIterator();
    void fetchData() ;
}
 
